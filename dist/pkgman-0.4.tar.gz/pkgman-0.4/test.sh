#!/bin/sh
# nymix - Package Management Script - Aaron Marks 2005
. ./pkgglobals.sh

case $1 in
    install)  
        pkgInstall $2
        ;;
    depinst)
        pkgDepInstall $2
        ;;
    remove)
        pkgRemove $2
        ;;
    info)
        pkgFind $2
        if [ "$?" == "0" ]; then
            echo "package not found"
            exit 1
        fi
        . $RETURN/$PKGFILE
        pkgInfo
        ;;
    installed)
    for i in $PKGINFO/*; do
        echo `echo $i | sed 's|.*/||'`
    done
        ;;
    *)
        echo "usage: $0 <command> <package name>"
        echo "  command can be:"
        echo "          install         - install package"
        echo "          remove          - remove package"
        echo "          info            - informatino about package"
        echo "          installed       - list installed packages"
esac

