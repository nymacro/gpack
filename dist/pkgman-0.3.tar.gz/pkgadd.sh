#!/bin/bash
#Aaron Marks 2005

#read global configuration file
. ~/pkgman/pkgglobals

#make sure there are enough parameters
if [[ $# < 1 ]]
then
    echo "not enough arguments.."
    exit 1
fi

if [ ! "$UID" -eq "0" ]
then
    echo "Should be root"
#    exit 1
fi

if [ ! -e "$1" ]; then
    echo "Package $1 not found!"
    exit 1
fi

PKGNAME=`echo $1 | sed 's/#.*//'`
echo $PKGNAME

if [ -e "$PKGROOT/$PKGNAME" ]
then
    echo "Package already installed..."
    exit 1
fi

#Check dependancies
for i in ${depends[@]}
do
    if [ ! -e "$PKGROOT/$i" ]; then
        echo "Dependancy $i not installed.."
        # BUILD THE DEPS!!!
        exit 1
    fi
done

#Check option dependancie

mkdir $PKGTMP

#extract
echo "Extracting..."

mkdir $PKGROOT/$PKGNAME
if tar zxvf $1 -C $PKGTMP > $PKGROOT/$PKGNAME/footprint
then
    mv $PKGTMP/PKGBUILD $PKGROOT/$PKGNAME

    #install files
    cp $PKGTMP/* $PKGVIR -R
else
    #error --
    echo "An error occurred when attempting to install package $1"
fi

#remove temp
echo "Removing temp..."
rm $PKGTMP -Rf

