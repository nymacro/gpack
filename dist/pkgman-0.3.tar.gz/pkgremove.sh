#!/bin/bash
#Aaron Marks 2005

#read global configuration file
. ~/pkgman/pkgglobals

if [[ $# < 1 ]]
then
    echo "not enough arguments.."
    exit 1
fi

if [ ! -e "$PKGROOT/$1" ]
then
    echo "Package not installed!"
    exit 1
fi

echo "Removing package..."
for i in `cat $PKGROOT/$1/footprint | sort -r`
do
    echo $PKGVIR/$i
    if [ ! "$i" == "PKGBUILD" ]; then
        if [ -d "$PKGVIR/$i" ]; then
            rmdir $PKGVIR/$i
        else
            rm -f $PKGVIR/$i
        fi
    fi
done

rm $PKGROOT/$1 -Rf

