#!/bin/bash
#Package Manager Base System
#Aaron Marks 2005  
#Tue Feb  1 13:21:18 EST 2005
#
#TODO:
# - Add md5sum for source to ensure source is unchanged and original.

#read global configure file
. ~/pkgman/pkgglobals

#get package info
if [ ! -e "./PKGBUILD" ]; then
    echo "PKGBUILD Not Found!"
    exit 1
fi

. ./PKGBUILD

#print package info
echo "Name: $pkgname"
echo "Version: $version"
echo "Release: $release"

echo "Dependancies:"
for i in ${depends[@]}
do
    echo "      $i"
done

echo "Optional Dependancie:"
for i in ${optdeps[@]}
do
    echo "      $i"
done

echo "Source Files:"
for i in ${sources[@]}
do
    echo "      $i"
done

#check UID
if [ "$UID" -eq "0" ]
then
    echo "Building as root..."
else
    echo "Package should be built by root."
fi

#set internal variables
PKGBUILD=`pwd`
PKG=$PKGBUILD/work/pkg
SRC=$PKGBUILD/work/src

#download source files
for i in ${sources[@]}
do
    SOURCEFILE=`echo $i | sed 's/.*\///'`
    if [ -e "$SOURCEFILE" ]
    then
        echo "Source found..."
    else
        echo "Downloading $i..."
        if wget $i
        then
            echo "got source!"
        else
            echo "Download failed!"
            exit 1
        fi
    fi
done

#check dependancies
for i in ${depends[@]}
do
#    if [ -d "$PKGROOT/$i" ]
#    then
#        echo "$i - Dependancy met."
#    else
#        echo "$i - Missing Dependancy"
#        exit 1
#    fi
    findPackage $i
    if [ "$?" ==  "0" ]; then
        echo "Cannot find dependancy $i"
    fi
    TMPTMP=`pwd`
    echo "Building dependancy $RETURN"
    cd $PKGDIR/$RETURN
    sh ~/pkgman/pkgmake.sh
    cd $TMPTMP
done

#create package environment
mkdir ./work
mkdir $PKG
mkdir $SRC

#extract source
for i in ${sources[@]}
do
    SOURCEFILE=`echo $i | sed 's/.*\///'`
    TYPE=`echo $SOURCEFILE | sed 's/.*\.//'`
    case $TYPE in
        gz)
        tar zxvf $PKGBUILD/$SOURCEFILE -C $SRC
        ;;
        bz2)
        tar jxvf $PKGBUILD/$SOURCEFILE -C $SRC
        ;;
    esac
done

#execute build
cd $SRC
if build
then
    echo "BUILD SUCCESSFULL!"
else
    echo "BUILD FAILED!"
    cd $PKGBUILD
    rm ./work -Rf
    exit 1
fi

#build package file
echo "Building package..."
cp $PKGBUILD/PKGBUILD $PKG
cd $PKG
if tar czvf $PKGBUILD/$pkgname\#$version-$release.tar.gz *
then
    echo "Built package sucessfully!"
else
    echo "Package construction failed. Check PKGFILE"
fi

#remove working dir
rm $PKGBUILD/work -Rf

