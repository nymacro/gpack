#!/bin/bash
#Aaron Marks 2005

PKGROOT=~/pkgman/root
PKGTMP=/tmp/`date +%s`
PKGVIR=~/pkgman/vfs

#make sure there are enough parameters
if [[ $# < 1 ]]
then
    echo "not enough arguments.."
    exit 1
fi

#if [ ! "$UID" -eq "0" ]
#then
#    echo "Must be root!"
#    exit 1
#fi

PKGNAME=`echo $1 | sed 's/#.*//'`
echo $PKGNAME

if [ -e "$PKGROOT/$PKGNAME" ]
then
    echo "Package already installed..."
    exit 1
fi

mkdir $PKGTMP

#extract
echo "Extracting..."

mkdir $PKGROOT/$PKGNAME
tar zxvf $1 -C $PKGTMP > $PKGROOT/$PKGNAME/footprint
mv $PKGTMP/PKGBUILD $PKGROOT/$PKGNAME

#install files
cp $PKGTMP/* $PKGVIR -R

#remove temp
echo "Removing temp..."
rm $PKGTMP -Rf

