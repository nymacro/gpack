#!/bin/bash
#Aaron Marks 2005

PKGROOT=~/pkgman/root
PKGVIR=~/pkgman/vfs

if [[ $# < 1 ]]
then
    echo "not enough arguments.."
    exit 1
fi

if [ ! -e "$PKGROOT/$1" ]
then
    echo "Package not installed!"
    exit 1
fi

echo "Removing package..."
for i in `cat $PKGROOT/$1/footprint`
do
    echo $PKGVIR/$i
    rm $PKGVIR/$i -f
done

rm $PKGROOT/$1 -Rf

